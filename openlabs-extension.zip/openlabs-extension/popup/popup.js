// src/utils/crypto.ts
function bytesToHex(bytes) {
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function generateSecret() {
  const bytes = globalThis.crypto.getRandomValues(new Uint8Array(32));
  return bytesToHex(bytes);
}
var SECRET_KEY = "openlabs_shared_secret";
async function storeSecret(secretHex) {
  await chrome.storage.session.set({ [SECRET_KEY]: secretHex });
}
async function getSecret() {
  const data = await chrome.storage.session.get(SECRET_KEY);
  const value = data[SECRET_KEY];
  return typeof value === "string" ? value : null;
}

// src/popup/popup.ts
var statusDot = document.getElementById("status-dot");
var statusLine = document.getElementById("status-line");
var identityEl = document.getElementById("identity");
var secretLenEl = document.getElementById("secret-len");
var logEl = document.getElementById("log");
var pairBtn = document.getElementById("pair-btn");
var rotateBtn = document.getElementById("rotate-btn");
var copyBtn = document.getElementById("copy-btn");
var clearBtn = document.getElementById("clear-btn");
function setState(state, label, meta) {
  statusDot.className = `dot ${state}`;
  statusLine.textContent = meta ? `${label} \u2014 ${meta}` : label;
  statusLine.classList.toggle("error", state === "error");
}
function pushLog(entry, tone = "plain") {
  if (logEl.children[0]?.textContent === "No activity.") logEl.innerHTML = "";
  const line = document.createElement("div");
  const t = document.createElement("span");
  const m = document.createElement("span");
  t.className = "t";
  t.textContent = `[${(/* @__PURE__ */ new Date()).toLocaleTimeString()}]`;
  m.className = tone === "plain" ? "m" : `m ${tone}`;
  m.textContent = entry;
  line.append(t, m);
  logEl.prepend(line);
  while (logEl.children.length > 40) {
    logEl.removeChild(logEl.lastChild);
  }
}
async function refreshIdentity() {
  const secret = await getSecret();
  if (secret) {
    identityEl.textContent = `secret: ${secret.slice(0, 20)}\u2026`;
    identityEl.style.color = "";
    secretLenEl.textContent = `${secret.length} hex`;
  } else {
    identityEl.textContent = "No shared secret yet.";
    identityEl.style.color = "var(--warn)";
    secretLenEl.textContent = "\u2014";
  }
}
async function pair() {
  pairBtn.disabled = true;
  pushLog("Pairing: creating shared secret\u2026", "warn");
  try {
    let secret = await getSecret();
    if (!secret) {
      secret = await generateSecret();
      await storeSecret(secret);
    }
    await chrome.runtime.sendMessage({ type: "OPENLABS_PAIR" });
    pushLog("Paired. Secret stored in session storage.", "ok");
    await refreshIdentity();
    setState("connected", "Pairing complete.");
  } catch (err) {
    pushLog(`Pairing failed: ${String(err)}`, "err");
    setState("error", "Pairing failed.");
  } finally {
    pairBtn.disabled = false;
  }
}
async function rotate() {
  rotateBtn.disabled = true;
  pushLog("Rotating shared secret\u2026", "warn");
  try {
    const secret = await generateSecret();
    await storeSecret(secret);
    await chrome.runtime.sendMessage({ type: "OPENLABS_ROTATE" });
    pushLog("Secret rotated.", "ok");
    await refreshIdentity();
  } catch (err) {
    pushLog(`Rotation failed: ${String(err)}`, "err");
  } finally {
    rotateBtn.disabled = false;
  }
}
async function copySecret() {
  const secret = await getSecret();
  if (!secret) {
    pushLog("Nothing to copy \u2014 no secret yet.", "warn");
    return;
  }
  try {
    await navigator.clipboard.writeText(secret);
    pushLog("Secret copied to clipboard.", "ok");
  } catch {
    pushLog("Clipboard unavailable.", "err");
  }
}
pairBtn.addEventListener("click", () => void pair());
rotateBtn.addEventListener("click", () => void rotate());
copyBtn.addEventListener("click", () => void copySecret());
clearBtn.addEventListener("click", () => {
  logEl.innerHTML = "";
  const line = document.createElement("span");
  line.className = "m";
  line.textContent = "No activity.";
  logEl.append(line);
});
chrome.runtime.onMessage.addListener((message) => {
  const msg = message;
  if (!msg) return;
  if (msg.type === "OPENLABS_STATUS") {
    const s = msg.status;
    if (!s) return;
    if (s.paused) {
      setState("paused", "Paused (CAPTCHA detected).");
    } else if (s.connected === true) {
      setState("connected", "Connected to local agent.");
    } else if (s.connected === false) {
      setState("disconnected", "Disconnected from local agent.", s.reason ?? s.error);
    }
  }
  if (msg.type === "OPENLABS_PAUSED") setState("paused", "Paused (CAPTCHA detected).");
});
void (async () => {
  statusLine.textContent = "contacting background\u2026";
  await refreshIdentity();
  try {
    const resp = await chrome.runtime.sendMessage({
      type: "OPENLABS_STATUS_QUERY"
    });
    if (resp?.status?.connected) {
      setState("connected", "Connected to local agent.");
    } else {
      setState("disconnected", "Disconnected from local agent.");
    }
  } catch {
    setState("unknown", "Background not reachable.");
  }
  pushLog("Dashboard ready.");
})();
