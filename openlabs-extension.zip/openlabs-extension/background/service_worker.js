var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/utils/crypto.ts
var crypto_exports = {};
__export(crypto_exports, {
  bytesToHex: () => bytesToHex,
  generateSecret: () => generateSecret,
  getSecret: () => getSecret,
  hexToBytes: () => hexToBytes,
  rotateSecret: () => rotateSecret,
  sign: () => sign,
  storeSecret: () => storeSecret,
  verify: () => verify
});
function bytesToHex(bytes) {
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function hexToBytes(hex) {
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) {
    out[i] = parseInt(hex.substr(i * 2, 2), 16);
  }
  return out;
}
async function getKey(secretHex) {
  const keyData = hexToBytes(secretHex);
  const buffer = keyData.buffer.slice(
    keyData.byteOffset,
    keyData.byteOffset + keyData.byteLength
  );
  return globalThis.crypto.subtle.importKey(
    "raw",
    buffer,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"]
  );
}
async function generateSecret() {
  const bytes = globalThis.crypto.getRandomValues(new Uint8Array(32));
  return bytesToHex(bytes);
}
async function sign(payload, secretHex) {
  const key = await getKey(secretHex);
  const encoded = new TextEncoder().encode(payload);
  const sig = await globalThis.crypto.subtle.sign("HMAC", key, encoded);
  return bytesToHex(new Uint8Array(sig));
}
async function verify(payload, providedSigHex, secretHex) {
  const key = await getKey(secretHex);
  const encoded = new TextEncoder().encode(payload);
  const sigBytes = hexToBytes(providedSigHex);
  const buffer = sigBytes.buffer.slice(
    sigBytes.byteOffset,
    sigBytes.byteOffset + sigBytes.byteLength
  );
  return globalThis.crypto.subtle.verify("HMAC", key, buffer, encoded);
}
async function storeSecret(secretHex) {
  await chrome.storage.session.set({ [SECRET_KEY]: secretHex });
}
async function getSecret() {
  const data = await chrome.storage.session.get(SECRET_KEY);
  const value = data[SECRET_KEY];
  return typeof value === "string" ? value : null;
}
async function rotateSecret() {
  const secret = await generateSecret();
  await storeSecret(secret);
  return secret;
}
var SECRET_KEY;
var init_crypto = __esm({
  "src/utils/crypto.ts"() {
    "use strict";
    SECRET_KEY = "openlabs_shared_secret";
  }
});

// src/background/ws_client.ts
var WS_URL = "ws://localhost:8080";
var FRESHNESS_WINDOW_MS = 3e4;
var CLOCK_TOLERANCE_MS = 6e4;
var REPLAY_MAX = 1024;
var SIGNATURE_FAIL_ALERT_THRESHOLD = 3;
var RECONNECT_DELAY_MS = 2e3;
var WsClient = class {
  ws = null;
  started = false;
  handler = null;
  signatureFailures = 0;
  replayCache = /* @__PURE__ */ new Set();
  setCommandHandler(fn) {
    this.handler = fn;
  }
  emitStatus(update) {
    chrome.runtime.sendMessage({ type: "OPENLABS_STATUS", status: update }).catch(() => {
    });
  }
  async connect() {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) return;
    this.started = true;
    return new Promise((resolve, reject) => {
      let ws;
      try {
        ws = new WebSocket(WS_URL);
      } catch (err) {
        reject(err);
        return;
      }
      this.ws = ws;
      ws.onopen = () => {
        this.signatureFailures = 0;
        this.emitStatus({ connected: true });
        void this.send({ type: "HELLO" });
        resolve();
      };
      ws.onmessage = (event) => {
        void this.handleInbound(event.data);
      };
      ws.onclose = () => {
        this.emitStatus({ connected: false, reason: "closed" });
        this.scheduleReconnect();
      };
      ws.onerror = (err) => {
        this.emitStatus({
          connected: false,
          reason: "error",
          error: String(err?.type || "websocket error")
        });
        reject(err);
      };
    });
  }
  scheduleReconnect() {
    if (!this.started) return;
    setTimeout(() => {
      void this.connect().catch(() => this.scheduleReconnect());
    }, RECONNECT_DELAY_MS);
  }
  recordSignatureFailure() {
    this.signatureFailures++;
    if (this.signatureFailures >= SIGNATURE_FAIL_ALERT_THRESHOLD) {
      this.signatureFailures = 0;
      try {
        new Notification("OpenLabs: Signature failure", {
          body: "Repeated signed-command failures detected. Possible replay/attack \u2014 review pairing."
        });
      } catch {
      }
    }
  }
  async handleInbound(raw) {
    let data;
    try {
      data = JSON.parse(raw);
    } catch {
      return;
    }
    const { id, command, sig, ts } = data;
    if (!command || !sig || !ts) {
      this.recordSignatureFailure();
      return;
    }
    const now = Date.now();
    if (now - Number(ts) > FRESHNESS_WINDOW_MS || Number(ts) - now > CLOCK_TOLERANCE_MS) {
      this.recordSignatureFailure();
      return;
    }
    const replayKey = `${id}:${ts}`;
    if (this.replayCache.has(replayKey)) {
      this.recordSignatureFailure();
      return;
    }
    this.replayCache.add(replayKey);
    while (this.replayCache.size > REPLAY_MAX) {
      this.replayCache.delete(this.replayCache.values().next().value);
    }
    const { getSecret: getSecret2, verify: verify2, sign: sign2 } = await Promise.resolve().then(() => (init_crypto(), crypto_exports));
    const secret = await getSecret2();
    if (!secret) {
      await this.send({ type: "ERROR", reason: "NO_SECRET" });
      return;
    }
    const ok = await verify2(raw, sig, secret);
    if (!ok) {
      this.recordSignatureFailure();
      return;
    }
    if (this.handler) {
      await this.handler(data);
    }
  }
  async send(message) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      return { ok: false, error: "not connected" };
    }
    const { getSecret: getSecret2, sign: sign2 } = await Promise.resolve().then(() => (init_crypto(), crypto_exports));
    const secret = await getSecret2();
    if (!secret) return { ok: false, error: "no secret" };
    const ts = Date.now();
    const withMeta = { ...message, ts };
    const raw = JSON.stringify(withMeta);
    const sig = await sign2(raw, secret);
    this.ws.send(JSON.stringify({ ...withMeta, sig }));
    return { ok: true };
  }
  async sendStatus(statusMsg) {
    await this.send(statusMsg);
  }
  close() {
    this.started = false;
    if (this.ws) {
      try {
        this.ws.close();
      } catch {
      }
    }
  }
};

// src/background/browser_session.ts
var INTERACTIVE_ROLES = /* @__PURE__ */ new Set([
  "button",
  "link",
  "textbox",
  "checkbox",
  "radio",
  "combobox",
  "listbox",
  "menuitem",
  "menuitemcheckbox",
  "menuitemradio",
  "option",
  "searchbox",
  "slider",
  "spinbutton",
  "switch",
  "tab",
  "treeitem"
]);
var BrowserSession = class {
  attachedTabId = null;
  lastTabId = null;
  lastWindowId = null;
  refs = /* @__PURE__ */ new Map();
  refCounter = 1;
  capturingTabs = /* @__PURE__ */ new Set();
  network = /* @__PURE__ */ new Map();
  groupColors = [
    "green",
    "yellow",
    "cyan",
    "orange",
    "pink",
    "grey"
  ];
  groupColorIndex = 0;
  groupColorsBySession = /* @__PURE__ */ new Map();
  attachedTabs = /* @__PURE__ */ new Set();
  constructor() {
    chrome.tabs.onRemoved.addListener((tabId) => {
      this.attachedTabs.delete(tabId);
      this.capturingTabs.delete(tabId);
      this.network.delete(tabId);
      if (this.attachedTabId === tabId) this.attachedTabId = null;
      if (this.lastTabId === tabId) this.lastTabId = null;
    });
    chrome.debugger.onDetach.addListener((source) => {
      const tabId = source.tabId;
      if (!tabId) return;
      this.attachedTabs.delete(tabId);
      this.capturingTabs.delete(tabId);
      this.network.delete(tabId);
      if (this.attachedTabId === tabId) this.attachedTabId = null;
    });
    chrome.debugger.onEvent.addListener((source, method, params) => {
      const tabId = source.tabId;
      if (!tabId || !this.capturingTabs.has(tabId)) return;
      const buffer = this.networkBuffer(tabId);
      if (method === "Network.requestWillBeSent") {
        const r = params;
        buffer.set(r.requestId, {
          requestId: r.requestId,
          url: r.request.url,
          method: r.request.method,
          timestamp: r.timestamp
        });
      } else if (method === "Network.responseReceived") {
        const r = params;
        const entry = buffer.get(r.requestId);
        if (entry) {
          entry.status = r.response.status;
          entry.mimeType = r.response.mimeType;
        }
      } else if (method === "Network.loadingFinished") {
        const r = params;
        const entry = buffer.get(r.requestId);
        if (entry) entry.completed = true;
      }
    });
  }
  // ---- attach / command --------------------------------------------------
  async attach(tabId) {
    if (this.attachedTabs.has(tabId)) {
      this.attachedTabId = tabId;
      return;
    }
    try {
      await chrome.debugger.detach({ tabId });
    } catch {
    }
    await chrome.debugger.attach({ tabId }, "1.3");
    this.attachedTabs.add(tabId);
    this.attachedTabId = tabId;
  }
  get attachedId() {
    return this.attachedTabId;
  }
  async command(method, params) {
    if (this.attachedTabId === null) {
      throw new Error("No tab attached. Call attach(tabId) or run a session tool first.");
    }
    return chrome.debugger.sendCommand(
      { tabId: this.attachedTabId },
      method,
      params ?? {}
    );
  }
  // ---- current-tab resolution -------------------------------------------
  setLast(tabId) {
    this.lastTabId = tabId;
  }
  setAttached(tabId) {
    this.attachedTabId = tabId;
  }
  async currentTab() {
    if (this.attachedTabId !== null) {
      try {
        const tab2 = await chrome.tabs.get(this.attachedTabId);
        if (tab2) return tab2;
      } catch {
        this.attachedTabId = null;
      }
    }
    if (this.lastTabId !== null) {
      try {
        const tab2 = await chrome.tabs.get(this.lastTabId);
        if (tab2) return tab2;
      } catch {
        this.lastTabId = null;
      }
    }
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error("No active tab found");
    this.lastTabId = tab.id;
    return tab;
  }
  // ---- ref registry ------------------------------------------------------
  resetRefs() {
    this.refs.clear();
    this.refCounter = 1;
  }
  assignRef(backendDOMNodeId, role, name) {
    const refId = `@e${this.refCounter++}`;
    this.refs.set(refId, { backendDOMNodeId, role, name });
    return refId;
  }
  getRef(refId) {
    const key = refId.startsWith("@") ? refId.slice(1) : refId;
    return this.refs.get(key);
  }
  isRef(refId) {
    return /^@?e\d+$/.test(refId);
  }
  async objectIdFromRef(refId) {
    const entry = this.getRef(refId);
    if (!entry) throw new Error(`Unknown ref "${refId}". Run snapshot first to get refs.`);
    const { object } = await this.command("DOM.resolveNode", {
      backendNodeId: entry.backendDOMNodeId
    });
    if (!object?.objectId) {
      throw new Error(`Could not resolve ref "${refId}" to a DOM element.`);
    }
    return object.objectId;
  }
  async objectIdFromSelector(selector) {
    const res = await this.command("Runtime.evaluate", {
      expression: `document.querySelector(${JSON.stringify(selector)})`,
      returnByValue: false
    });
    if (res.exceptionDetails) throw new Error(res.exceptionDetails.text);
    if (res.result?.subtype === "null" || !res.result?.objectId) {
      throw new Error(`Element not found: ${selector}`);
    }
    return res.result.objectId;
  }
  // ---- tab groups (session coloring) -------------------------------------
  async groupTab(tabId, sessionKey, sessionTitle) {
    if (!sessionKey) return;
    const existingColor = this.groupColorsBySession.get(sessionKey);
    if (existingColor === void 0) {
      this.groupColorsBySession.set(
        sessionKey,
        this.groupColors[this.groupColorIndex++ % this.groupColors.length]
      );
    }
    try {
      const existingGroups = await chrome.tabGroups.query({
        title: sessionTitle ?? `agent:${sessionKey}`
      });
      let groupId = existingGroups[0]?.id;
      if (groupId === void 0) {
        groupId = await chrome.tabs.group({ tabIds: tabId });
        await chrome.tabGroups.update(groupId, {
          title: sessionTitle ?? `agent:${sessionKey}`,
          color: this.groupColorsBySession.get(sessionKey),
          collapsed: false
        });
      } else {
        await chrome.tabs.group({ tabIds: tabId, groupId });
      }
    } catch {
    }
  }
  // ---- network capture ----------------------------------------------------
  networkBuffer(tabId) {
    let buffer = this.network.get(tabId);
    if (!buffer) {
      buffer = /* @__PURE__ */ new Map();
      this.network.set(tabId, buffer);
    }
    return buffer;
  }
  async networkStart() {
    const tab = await this.currentTab();
    await this.attach(tab.id);
    this.network.set(tab.id, /* @__PURE__ */ new Map());
    this.capturingTabs.add(tab.id);
    await this.command("Network.enable");
    return { success: true, message: "network capture started" };
  }
  async networkStop() {
    const tabId = this.attachedTabId;
    if (tabId !== null && this.capturingTabs.has(tabId)) {
      this.capturingTabs.delete(tabId);
      try {
        await this.command("Network.disable");
      } catch {
      }
    }
    return { success: true, message: "network capture stopped" };
  }
  networkList(filter) {
    const tabId = this.attachedTabId;
    let entries = [...(tabId === null ? /* @__PURE__ */ new Map() : this.networkBuffer(tabId)).values()];
    if (filter) entries = entries.filter((e) => e.url.includes(filter));
    return {
      count: entries.length,
      requests: entries.map((e) => ({
        requestId: e.requestId,
        url: e.url,
        method: e.method,
        status: e.status,
        mimeType: e.mimeType,
        completed: e.completed ?? false
      }))
    };
  }
  async networkDetail(requestId) {
    const tabId = this.attachedTabId;
    const entry = (tabId === null ? /* @__PURE__ */ new Map() : this.networkBuffer(tabId)).get(requestId);
    if (!entry) throw new Error(`network: request "${requestId}" not found`);
    const resp = await this.command("Network.getResponseBody", { requestId });
    let body = resp.body;
    if (!resp.base64Encoded) {
      try {
        body = JSON.parse(resp.body);
      } catch {
      }
    }
    return { ...entry, base64Encoded: resp.base64Encoded, body };
  }
};

// src/background/approval.ts
var APPROVAL_TIMEOUT_MS = 6e4;
var ApprovalGate = class {
  pending = /* @__PURE__ */ new Map();
  request(requestId, details, sendFn) {
    void sendFn({
      type: "APPROVAL_REQUEST",
      requestId,
      tool: details
    });
    return new Promise((resolve) => {
      const timer = setTimeout(() => {
        this.pending.delete(requestId);
        resolve(false);
      }, APPROVAL_TIMEOUT_MS);
      this.pending.set(requestId, {
        resolve,
        timer
      });
    });
  }
  resolve(requestId, approved) {
    const entry = this.pending.get(requestId);
    if (!entry) return false;
    clearTimeout(entry.timer);
    this.pending.delete(requestId);
    entry.resolve(approved);
    return true;
  }
};

// src/background/captcha_detector.ts
var CHALLENGE_SELECTORS = [
  'iframe[src*="captcha"]',
  'iframe[src*="recaptcha"]',
  'iframe[src*="hcaptcha"]',
  ".g-recaptcha",
  "#g-recaptcha",
  ".h-captcha",
  "#h-captcha",
  "[data-sitekey]",
  "#challenge-running",
  "#challenge-stage",
  '[id*="cf-chl"]',
  ".cf-challenges-running",
  '[id^="challenge-"]',
  'form[action*="captcha"]',
  '[aria-label*="captcha" i]',
  '[aria-label*="recaptcha" i]'
];
var CHALLENGE_STATUS_CODES = /* @__PURE__ */ new Set([403, 503]);
var EVAL_SNIPPET = `(() => {
  const selectors = ${JSON.stringify(CHALLENGE_SELECTORS)};
  for (const sel of selectors) {
    if (document.querySelector(sel)) return { detected: true, selector: sel };
  }
  return { detected: false };
})()`;
var CaptchaDetector = class {
  constructor(opts) {
    this.opts = opts;
  }
  pendingPause = false;
  notifyUser() {
    if (this.opts.notifyFn) {
      this.opts.notifyFn(
        "OpenLabs: Human verification required",
        "A CAPTCHA / bot-challenge was detected. The agent is paused \u2014 please resolve it manually."
      );
      return;
    }
    try {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icon/128.png",
        title: "OpenLabs: Human verification required",
        message: "A CAPTCHA / bot-challenge was detected. The agent is paused \u2014 please resolve it manually."
      });
    } catch {
    }
  }
  async evaluate(httpStatus) {
    let domDetected = false;
    let matchedSelector;
    let iframeSeen = false;
    try {
      const res = await this.opts.session.command("Runtime.evaluate", {
        expression: EVAL_SNIPPET,
        returnByValue: true
      });
      const value = res?.result?.value;
      domDetected = !!value?.detected;
      matchedSelector = value?.selector;
    } catch {
    }
    if (httpStatus !== void 0 && CHALLENGE_STATUS_CODES.has(httpStatus)) {
    }
    const statusChallenge = httpStatus !== void 0 && CHALLENGE_STATUS_CODES.has(httpStatus);
    const detected = domDetected || iframeSeen || statusChallenge;
    if (detected && !this.pendingPause) {
      this.pendingPause = true;
      try {
        await this.opts.sendFn({
          type: "STATUS",
          status: "CAPTCHA_DETECTED",
          challenge: {
            dom: domDetected,
            matchedSelector,
            iframes: iframeSeen,
            httpStatus: httpStatus ?? null
          },
          at: (/* @__PURE__ */ new Date()).toISOString()
        });
        this.notifyUser();
      } finally {
        this.pendingPause = false;
      }
    }
    return detected;
  }
};

// src/background/service_worker.ts
init_crypto();

// src/background/tools/navigate.ts
var navigate = {
  name: "navigate",
  async execute(args, ctx) {
    const url = args.url;
    if (!url) throw new Error("navigate: url is required");
    const newTab = !!args.newTab;
    const sessionKey = args._session;
    const groupTitle = args.group_title;
    if (newTab) {
      const tab2 = await chrome.tabs.create({ url, active: false });
      ctx.session.setLast(tab2.id);
      if (sessionKey) await ctx.session.groupTab(tab2.id, sessionKey, groupTitle);
      await ctx.session.attach(tab2.id);
      await waitForLoad(ctx, tab2.id);
      return { success: true, url, tabId: tab2.id };
    }
    let tab;
    try {
      tab = await ctx.session.currentTab();
    } catch {
      const created = await chrome.tabs.create({ url, active: false });
      ctx.session.setLast(created.id);
      if (sessionKey) await ctx.session.groupTab(created.id, sessionKey, groupTitle);
      await ctx.session.attach(created.id);
      await waitForLoad(ctx, created.id);
      return { success: true, url, tabId: created.id };
    }
    if (tab.url?.startsWith("chrome://") || tab.url?.startsWith("edge://")) {
      const created = await chrome.tabs.create({ url, active: false });
      ctx.session.setLast(created.id);
      await waitForLoad(ctx, created.id);
      return { success: true, url, tabId: created.id };
    }
    await ctx.session.attach(tab.id);
    ctx.session.setLast(tab.id);
    const sameUrl = tab.url === url || tab.url === url + "/";
    let frameId;
    if (sameUrl) {
      await ctx.session.command("Page.reload", { ignoreCache: true });
    } else {
      const res = await ctx.session.command("Page.navigate", { url });
      frameId = res?.frameId;
    }
    await waitForLoad(ctx, tab.id);
    return { success: true, url, tabId: tab.id, frameId };
  }
};
function waitForLoad(ctx, tabId) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const finish = (fn) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      fn();
    };
    const timer = setTimeout(() => {
      finish(() => reject(new Error("navigate: page load timeout (30s)")));
    }, 3e4);
    const isLoaded = (tab) => tab.status === "complete" && !!tab.url && tab.url !== "about:blank";
    const listener = (updatedId, changeInfo, tab) => {
      if (updatedId === tabId && changeInfo.status === "complete" && isLoaded(tab)) {
        finish(() => resolve());
      }
    };
    chrome.tabs.get(tabId).then((tab) => {
      if (isLoaded(tab)) {
        finish(() => resolve());
      } else {
        chrome.tabs.onUpdated.addListener(listener);
      }
    });
  });
}

// src/background/tools/find_tab.ts
function hostnamePattern(url) {
  if (url.includes("*")) return url;
  try {
    return `*://${new URL(url).hostname}/*`;
  } catch {
    return `*://${url.replace(/^\.+/, "")}/*`;
  }
}
function matches(tabUrl, pattern) {
  try {
    return new URL(tabUrl).hostname === pattern.replace(/^\*:\/\//, "").replace(/\/\*$/, "");
  } catch {
    return false;
  }
}
var find_tab = {
  name: "find_tab",
  async execute(args, ctx) {
    const url = args.url;
    if (!url) throw new Error("find_tab: url is required");
    const active = !!args.active;
    const patterns = args._tabIds;
    const needle = hostnamePattern(url);
    if (active) {
      const win = await chrome.windows.getLastFocused({
        populate: true,
        windowTypes: ["normal"]
      });
      const tab = win.tabs?.find(
        (t) => t.active && t.url && matches(t.url, needle)
      );
      if (!tab?.id) {
        throw new Error(
          `find_tab(active:true): no foreground tab matching ${url} \u2014 the user isn't viewing that page right now`
        );
      }
      await ctx.session.attach(tab.id);
      ctx.session.setLast(tab.id);
      return { success: true, url: tab.url ?? url, tabId: tab.id, borrowed: true };
    }
    for (const id of patterns ?? []) {
      let tab;
      try {
        tab = await chrome.tabs.get(id);
      } catch {
        continue;
      }
      if (tab.url && matches(tab.url, needle)) {
        await ctx.session.attach(id);
        ctx.session.setLast(id);
        return { success: true, url: tab.url, tabId: id, borrowed: false };
      }
    }
    throw new Error(
      `find_tab: no tab matching ${url} in this session \u2014 use navigate to open it, or pass active:true to act on a tab you already have open`
    );
  }
};

// src/background/tools/evaluate.ts
var evaluate = {
  name: "evaluate",
  async execute(args, ctx) {
    const code = args.code;
    if (!code) throw new Error("evaluate: code is required");
    const tab = await ctx.session.currentTab();
    await ctx.session.attach(tab.id);
    const res = await ctx.session.command("Runtime.evaluate", {
      expression: code,
      returnByValue: true,
      awaitPromise: true
    });
    if (res.exceptionDetails) {
      const detail = res.exceptionDetails.exception?.description || res.exceptionDetails.text;
      throw new Error(`evaluate: ${detail}`);
    }
    return { type: res.result.type, value: res.result.value };
  }
};

// src/background/tools/network.ts
var network = {
  name: "network",
  async execute(args, ctx) {
    const cmd = args.cmd;
    if (!cmd) throw new Error("network: cmd is required (start/stop/list/detail)");
    switch (cmd) {
      case "start":
        return ctx.session.networkStart();
      case "stop":
        return ctx.session.networkStop();
      case "list":
        return ctx.session.networkList(
          typeof args.filter === "string" ? args.filter : void 0
        );
      case "detail": {
        const requestId = args.requestId;
        if (!requestId) throw new Error("network: requestId is required for detail");
        return ctx.session.networkDetail(requestId);
      }
      default:
        throw new Error(`network: unknown cmd "${cmd}"`);
    }
  }
};

// src/background/tools/snapshot.ts
function formatChildren(ax, byId, session2) {
  const role = ax.role?.value;
  if (!role || role === "none" || role === "generic") {
    if (ax.childIds?.length) {
      const kids = [];
      for (const cid of ax.childIds) {
        const child = byId.get(cid);
        if (!child) continue;
        const formatted = formatChildren(child, byId, session2);
        if (formatted) {
          kids.push(...Array.isArray(formatted) ? formatted : [formatted]);
        }
      }
      return kids.length === 1 ? kids[0] : kids.length > 0 ? kids : null;
    }
    return null;
  }
  const node = { role };
  if (ax.name?.value) node.name = ax.name.value;
  if (ax.value?.value) node.value = ax.value.value;
  if (ax.description?.value) node.description = ax.description.value;
  if (INTERACTIVE_ROLES.has(role) && ax.backendDOMNodeId != null) {
    node.ref = `@${session2.assignRef(ax.backendDOMNodeId, role, ax.name?.value ?? "")}`;
  }
  if (ax.childIds?.length) {
    const kids = [];
    for (const cid of ax.childIds) {
      const child = byId.get(cid);
      if (!child) continue;
      const formatted = formatChildren(child, byId, session2);
      if (formatted) {
        kids.push(...Array.isArray(formatted) ? formatted : [formatted]);
      }
    }
    if (kids.length > 0) node.children = kids;
  }
  return node;
}
var snapshot = {
  name: "snapshot",
  async execute(args, ctx) {
    const tab = await ctx.session.currentTab();
    await ctx.session.attach(tab.id);
    ctx.session.resetRefs();
    const res = await ctx.session.command("Accessibility.getFullAXTree");
    const nodes = res.nodes ?? [];
    const byId = /* @__PURE__ */ new Map();
    for (const n of nodes) byId.set(n.nodeId, n);
    let tree = [];
    if (nodes.length > 0) {
      const root = byId.get(nodes[0].nodeId) ?? nodes[0];
      const formatted = formatChildren(root, byId, ctx.session);
      if (formatted) {
        tree = Array.isArray(formatted) ? formatted : [formatted];
      }
    }
    return { url: tab.url, title: tab.title, tree };
  }
};

// src/utils/sensitive.ts
var SENSITIVE_ACTION_PATTERNS = [
  /\bpay\b/i,
  /confirm\s+order/i,
  /submit\s+payment/i,
  /\bsign\s*in\b/i,
  /\blog\s*in\b/i,
  /place\s*order/i,
  /checkout/i,
  /\bdelete\b/i,
  /purchase/i,
  /buy\s+now/i,
  /authorize\b/i,
  /confirm\b/i,
  /\btransfer\b/i,
  /\bdonate\b/i
];
function isSensitiveAction(text) {
  const haystack = String(text || "").trim().toLowerCase();
  return SENSITIVE_ACTION_PATTERNS.some((re) => re.test(haystack));
}

// src/background/tools/guard.ts
async function resolveObjectId(ctx, target) {
  if (target.ref) return ctx.session.objectIdFromRef(target.ref);
  if (target.selector) return ctx.session.objectIdFromSelector(target.selector);
  throw new Error("target requires ref or selector");
}
async function elementText(ctx, objectId) {
  const res = await ctx.session.command("Runtime.callFunctionOn", {
    objectId,
    functionDeclaration: `function() {
      let aria = '';
      try { aria = this.getAttribute && String(this.getAttribute('aria-label') || ''); } catch (_e) {}
      return String(this.textContent || '') + ' ' + aria;
    }`,
    returnByValue: true
  });
  return String(res?.result?.value ?? "");
}
async function guardedElement(ctx, tool, args, requestId) {
  const target = {
    ref: args.ref,
    selector: args.selector
  };
  const objectId = await resolveObjectId(ctx, target);
  const text = await elementText(ctx, objectId);
  if (isSensitiveAction(text)) {
    const approved = await ctx.approval.request(
      requestId,
      { tool, target: { ...target, text: text.slice(0, 120) } },
      ctx.send
    );
    if (!approved) {
      throw new Error(
        "Action denied: this target matches a sensitive-action pattern and human approval was not given."
      );
    }
  }
  return objectId;
}

// src/background/tools/click.ts
var click = {
  name: "click",
  async execute(args, ctx) {
    const selector = args.selector;
    if (!selector)
      throw new Error("click: selector is required (CSS selector or @e ref)");
    const tab = await ctx.session.currentTab();
    await ctx.session.attach(tab.id);
    const requestId = args.__requestId || `click-${Date.now()}`;
    const objectId = await guardedElement(ctx, "click", args, requestId);
    const res = await ctx.session.command("Runtime.callFunctionOn", {
      objectId,
      functionDeclaration: `function() {
        this.scrollIntoView({ block: 'center' });
        this.click();
        return { success: true, tag: this.tagName, text: this.textContent?.slice(0, 100) };
      }`,
      returnByValue: true
    });
    if (res.exceptionDetails) throw new Error(`click: ${res.exceptionDetails.text}`);
    return res.result.value || {
      success: true
    };
  }
};

// src/background/tools/fill.ts
var FILL_FUNCTION = `function() {
  const __target = this;
  __target.focus();
  if (__target.isContentEditable) {
    const __sel = window.getSelection();
    if (__sel) {
      const __range = document.createRange();
      __range.selectNodeContents(__target);
      __sel.removeAllRanges();
      __sel.addRange(__range);
    }
    let __inserted = false;
    try {
      __inserted = document.execCommand('insertText', false, arguments[0]);
    } catch (_e) {
      __inserted = false;
    }
    if (!__inserted) {
      __target.textContent = arguments[0];
      __target.dispatchEvent(new InputEvent('input', {
        inputType: 'insertText',
        data: arguments[0],
        bubbles: true,
      }));
    }
    return { success: true, tag: __target.tagName, mode: 'contenteditable' };
  }
  const __nativeSetter = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype, 'value'
  )?.set || Object.getOwnPropertyDescriptor(
    window.HTMLTextAreaElement.prototype, 'value'
  )?.set;
  if (__nativeSetter) {
    __nativeSetter.call(__target, arguments[0]);
  } else {
    __target.value = arguments[0];
  }
  __target.dispatchEvent(new Event('input', { bubbles: true }));
  __target.dispatchEvent(new Event('change', { bubbles: true }));
  return { success: true, tag: __target.tagName, mode: 'value' };
}`;
var fill = {
  name: "fill",
  async execute(args, ctx) {
    const selector = args.selector;
    const value = args.value;
    if (!selector)
      throw new Error("fill: selector is required (CSS selector or @e ref)");
    if (value == null) throw new Error("fill: value is required");
    const tab = await ctx.session.currentTab();
    await ctx.session.attach(tab.id);
    const requestId = args.__requestId || `fill-${Date.now()}`;
    const objectId = await guardedElement(ctx, "fill", args, requestId);
    const res = await ctx.session.command("Runtime.callFunctionOn", {
      objectId,
      functionDeclaration: FILL_FUNCTION,
      arguments: [{ value }],
      returnByValue: true
    });
    if (res.exceptionDetails) throw new Error(`fill: ${res.exceptionDetails.text}`);
    return res.result.value || { success: true };
  }
};

// src/background/tools/mouse_click.ts
var mouse_click = {
  name: "mouse_click",
  async execute(args, ctx) {
    const selector = args.selector;
    if (!selector)
      throw new Error(
        "mouse_click: selector is required (CSS selector or @e ref)"
      );
    const tab = await ctx.session.currentTab();
    await ctx.session.attach(tab.id);
    const requestId = args.__requestId || `mouse-click-${Date.now()}`;
    const objectId = await guardedElement(ctx, "mouse_click", args, requestId);
    await ctx.session.command("Runtime.callFunctionOn", {
      objectId,
      functionDeclaration: `function() {
        this.scrollIntoView({ block: 'center', inline: 'center' });
      }`
    });
    let model;
    try {
      const box = await ctx.session.command("DOM.getBoxModel", { objectId });
      model = box?.model;
    } catch (err) {
      throw new Error(
        `mouse_click: element has no layout box (display:none / detached / zero-size). Use 'click' for DOM-level fallback. (CDP: ${err.message})`
      );
    }
    const content = model?.content;
    if (!content || content.length < 8) {
      throw new Error(
        "mouse_click: element has no layout box (display:none / detached / zero-size). Use 'click' for DOM-level fallback."
      );
    }
    const x = (content[0] + content[2] + content[4] + content[6]) / 4;
    const y = (content[1] + content[3] + content[5] + content[7]) / 4;
    await ctx.session.command("Input.dispatchMouseEvent", {
      type: "mouseMoved",
      x,
      y,
      button: "none",
      buttons: 0
    });
    await ctx.session.command("Input.dispatchMouseEvent", {
      type: "mousePressed",
      x,
      y,
      button: "left",
      buttons: 1,
      clickCount: 1
    });
    await ctx.session.command("Input.dispatchMouseEvent", {
      type: "mouseReleased",
      x,
      y,
      button: "left",
      buttons: 0,
      clickCount: 1
    });
    const info = await ctx.session.command("Runtime.callFunctionOn", {
      objectId,
      functionDeclaration: `function() {
        return { tag: this.tagName, text: (this.textContent || '').slice(0, 100) };
      }`,
      returnByValue: true
    });
    return {
      success: true,
      x: Math.round(x),
      y: Math.round(y),
      tag: info?.result?.value?.tag ?? "",
      text: info?.result?.value?.text ?? ""
    };
  }
};

// src/background/tools/cdp.ts
var cdp = {
  name: "cdp",
  async execute(args, ctx) {
    const method = args.method;
    if (!method)
      throw new Error('cdp: method is required (e.g., "Input.dispatchMouseEvent")');
    const params = args.params ?? {};
    const tab = await ctx.session.currentTab();
    await ctx.session.attach(tab.id);
    const result = await ctx.session.command(method, params);
    if (result == null) return {};
    if (typeof result === "object" && !Array.isArray(result)) return result;
    return { value: result };
  }
};

// src/background/tools/key_type.ts
var key_type = {
  name: "key_type",
  async execute(args, ctx) {
    const text = args.text;
    if (typeof text !== "string")
      throw new Error("key_type: text is required (string)");
    const tab = await ctx.session.currentTab();
    await ctx.session.attach(tab.id);
    await ctx.session.command("Input.insertText", { text });
    return { success: true, length: text.length };
  }
};

// src/background/tools/send_keys.ts
var MODIFIERS = {
  alt: { bit: 1, key: "Alt", code: "AltLeft", vkc: 18 },
  ctrl: { bit: 2, key: "Control", code: "ControlLeft", vkc: 17 },
  control: { bit: 2, key: "Control", code: "ControlLeft", vkc: 17 },
  cmd: { bit: 4, key: "Meta", code: "MetaLeft", vkc: 91 },
  meta: { bit: 4, key: "Meta", code: "MetaLeft", vkc: 91 },
  shift: { bit: 8, key: "Shift", code: "ShiftLeft", vkc: 16 }
};
var SHIFT_BIT = MODIFIERS.shift.bit;
var platform = null;
async function getOs() {
  if (platform === null) {
    const info = await chrome.runtime.getPlatformInfo();
    platform = info.os;
  }
  return platform;
}
function defaultModifier() {
  return platform === "mac" ? MODIFIERS.cmd : MODIFIERS.ctrl;
}
var NAMED_KEYS = {
  enter: { key: "Enter", code: "Enter", vkc: 13, text: "\r" },
  return: { key: "Enter", code: "Enter", vkc: 13, text: "\r" },
  escape: { key: "Escape", code: "Escape", vkc: 27 },
  esc: { key: "Escape", code: "Escape", vkc: 27 },
  tab: { key: "Tab", code: "Tab", vkc: 9 },
  backspace: { key: "Backspace", code: "Backspace", vkc: 8 },
  delete: { key: "Delete", code: "Delete", vkc: 46 },
  space: { key: " ", code: "Space", vkc: 32, text: " " },
  arrowup: { key: "ArrowUp", code: "ArrowUp", vkc: 38 },
  arrowdown: { key: "ArrowDown", code: "ArrowDown", vkc: 40 },
  arrowleft: { key: "ArrowLeft", code: "ArrowLeft", vkc: 37 },
  arrowright: { key: "ArrowRight", code: "ArrowRight", vkc: 39 },
  home: { key: "Home", code: "Home", vkc: 36 },
  end: { key: "End", code: "End", vkc: 35 },
  pageup: { key: "PageUp", code: "PageUp", vkc: 33 },
  pagedown: { key: "PageDown", code: "PageDown", vkc: 34 }
};
function keySpec(key) {
  const lower = key.toLowerCase();
  if (NAMED_KEYS[lower]) return NAMED_KEYS[lower];
  const fnMatch = lower.match(/^f(\d{1,2})$/);
  if (fnMatch) {
    const num = parseInt(fnMatch[1], 10);
    if (num >= 1 && num <= 12) {
      return { key: `F${num}`, code: `F${num}`, vkc: 111 + num };
    }
  }
  if (key.length === 1) {
    if (/^[a-zA-Z]$/.test(key)) {
      const upper = key.toUpperCase();
      return {
        key: key.toLowerCase(),
        code: `Key${upper}`,
        vkc: upper.charCodeAt(0),
        text: key.toLowerCase()
      };
    }
    if (/^[0-9]$/.test(key)) {
      return { key, code: `Digit${key}`, vkc: key.charCodeAt(0), text: key };
    }
  }
  throw new Error(
    `send_keys: unknown key "${key}". Supported: ${Object.keys(NAMED_KEYS).join(", ")}, F1-F12, single letters/digits.`
  );
}
function parseSegment(segment) {
  const parts = segment.split("+").map((s) => s.trim()).filter(Boolean);
  if (parts.length === 0) throw new Error("send_keys: empty segment");
  let bits = 0;
  const modKeys = [];
  for (let i = 0; i < parts.length - 1; i++) {
    const name = parts[i].toLowerCase();
    const mod = name === "mod" ? defaultModifier() : MODIFIERS[name];
    if (!mod) {
      throw new Error(
        `send_keys: "${parts[i]}" is not a modifier. Use Alt/Ctrl/Cmd/Meta/Shift, or Mod (auto-resolves to Cmd on Mac, Ctrl on Win/Linux).`
      );
    }
    bits |= mod.bit;
    modKeys.push(mod);
  }
  return { modifierBits: bits, modifierKeys: modKeys, spec: keySpec(parts[parts.length - 1]) };
}
function uppercaseWhenShiftHeld(spec, shiftHeld) {
  if (!shiftHeld || spec.key.length !== 1 || !/^[a-z]$/.test(spec.key)) return spec;
  return { ...spec, key: spec.key.toUpperCase(), text: spec.key.toUpperCase() };
}
var send_keys = {
  name: "send_keys",
  async execute(args, ctx) {
    const keys = args.keys;
    if (typeof keys !== "string" || !keys.trim()) {
      throw new Error(
        'send_keys: keys is required (string), e.g. "Enter" or "Mod+A" or "Shift+Tab" or "Enter Escape"'
      );
    }
    const repeat = args.repeat === void 0 ? 1 : Number(args.repeat);
    if (!Number.isInteger(repeat) || repeat < 1 || repeat > 100) {
      throw new Error("send_keys: repeat must be an integer in [1, 100]");
    }
    const os = await getOs();
    platform = os;
    const segments = keys.trim().split(/\s+/).map((s) => parseSegment(s));
    const tab = await ctx.session.currentTab();
    await ctx.session.attach(tab.id);
    let dispatched = 0;
    for (let r = 0; r < repeat; r++) {
      for (const { modifierBits, modifierKeys, spec } of segments) {
        const final = uppercaseWhenShiftHeld(spec, (modifierBits & SHIFT_BIT) !== 0);
        let modMask = 0;
        for (const mod of modifierKeys) {
          modMask |= mod.bit;
          await ctx.session.command("Input.dispatchKeyEvent", {
            type: "keyDown",
            modifiers: modMask,
            key: mod.key,
            code: mod.code,
            windowsVirtualKeyCode: mod.vkc
          });
        }
        const textOnly = (modifierBits & ~SHIFT_BIT) === 0 && final.text !== void 0;
        await ctx.session.command("Input.dispatchKeyEvent", {
          type: "keyDown",
          modifiers: modifierBits,
          key: final.key,
          code: final.code,
          windowsVirtualKeyCode: final.vkc,
          ...textOnly ? { text: final.text } : {}
        });
        await ctx.session.command("Input.dispatchKeyEvent", {
          type: "keyUp",
          modifiers: modifierBits,
          key: final.key,
          code: final.code,
          windowsVirtualKeyCode: final.vkc
        });
        for (let i = modifierKeys.length - 1; i >= 0; i--) {
          const mod = modifierKeys[i];
          modMask &= ~mod.bit;
          await ctx.session.command("Input.dispatchKeyEvent", {
            type: "keyUp",
            modifiers: modMask,
            key: mod.key,
            code: mod.code,
            windowsVirtualKeyCode: mod.vkc
          });
        }
        dispatched++;
      }
    }
    return { success: true, dispatched, os };
  }
};

// src/background/tools/screenshot.ts
var screenshot = {
  name: "screenshot",
  async execute(args, ctx) {
    const tab = await ctx.session.currentTab();
    await ctx.session.attach(tab.id);
    const format = args.format || "png";
    const quality = format === "jpeg" ? args.quality || 80 : void 0;
    const selector = typeof args.selector === "string" ? args.selector : "";
    const params = { format };
    if (quality !== void 0) params.quality = quality;
    if (selector) {
      const objectId = ctx.session.isRef(selector) ? await ctx.session.objectIdFromRef(selector) : await ctx.session.objectIdFromSelector(selector);
      await ctx.session.command("Runtime.callFunctionOn", {
        objectId,
        functionDeclaration: `function() { this.scrollIntoView({ block: 'center', inline: 'center' }); }`
      });
      let box;
      try {
        box = await ctx.session.command("DOM.getBoxModel", { objectId });
      } catch (err) {
        throw new Error(
          `screenshot: element has no layout box (display:none / detached / zero-size). (CDP: ${err.message})`
        );
      }
      const border = box?.model?.border;
      if (!border || border.length < 8) {
        throw new Error(
          "screenshot: element has no layout box (display:none / detached / zero-size)."
        );
      }
      const xs = [border[0], border[2], border[4], border[6]];
      const ys = [border[1], border[3], border[5], border[7]];
      const x = Math.min(...xs);
      const y = Math.min(...ys);
      const width = Math.max(...xs) - x;
      const height = Math.max(...ys) - y;
      if (width <= 0 || height <= 0) {
        throw new Error(`screenshot: element has zero-size box (width=${width}, height=${height}).`);
      }
      params.clip = { x, y, width, height, scale: 1 };
    }
    const res = await ctx.session.command("Page.captureScreenshot", params);
    return {
      format,
      dataLength: res.data.length,
      data: res.data
    };
  }
};

// src/background/tools/save_as_pdf.ts
var PAPER_SIZES = {
  letter: [8.5, 11],
  legal: [8.5, 14],
  a4: [8.27, 11.69],
  a3: [11.69, 16.54],
  tabloid: [11, 17]
};
var save_as_pdf = {
  name: "save_as_pdf",
  async execute(args, ctx) {
    const tab = await ctx.session.currentTab();
    await ctx.session.attach(tab.id);
    const [width, height] = PAPER_SIZES[args.paper_format?.toLowerCase() ?? "letter"] ?? PAPER_SIZES.letter;
    const scale = typeof args.scale === "number" ? args.scale : 1;
    if (scale < 0.1 || scale > 2) {
      throw new Error(`save_as_pdf: scale must be in [0.1, 2.0], got ${scale}`);
    }
    const res = await ctx.session.command("Page.printToPDF", {
      printBackground: args.print_background !== false,
      landscape: !!args.landscape,
      scale,
      paperWidth: width,
      paperHeight: height,
      preferCSSPageSize: true
    });
    if (!res?.data) throw new Error("save_as_pdf: CDP Page.printToPDF returned no data");
    let pageTitle = "";
    try {
      const title = await ctx.session.command("Runtime.evaluate", {
        expression: "document.title",
        returnByValue: true
      });
      pageTitle = title?.result?.value ?? "";
    } catch {
    }
    return {
      data: res.data,
      mimeType: "application/pdf",
      dataLength: res.data.length,
      pageTitle,
      requestedFileName: args.file_name || ""
    };
  }
};

// src/background/tools/upload.ts
var upload = {
  name: "upload",
  async execute(args, ctx) {
    const selector = args.selector;
    const files = args.files;
    if (!selector)
      throw new Error("upload: selector is required (CSS selector for file input)");
    if (!files || !Array.isArray(files) || files.length === 0) {
      throw new Error("upload: files is required (array of local file paths)");
    }
    const tab = await ctx.session.currentTab();
    await ctx.session.attach(tab.id);
    const doc = await ctx.session.command("DOM.getDocument");
    const { nodeId } = await ctx.session.command("DOM.querySelector", {
      nodeId: doc.root.nodeId,
      selector
    });
    if (!nodeId) throw new Error(`upload: element not found: ${selector}`);
    await ctx.session.command("DOM.setFileInputFiles", {
      files,
      nodeId
    });
    return { success: true, selector, fileCount: files.length, files };
  }
};

// src/background/tools/close_tab.ts
var close_tab = {
  name: "close_tab",
  async execute(args, ctx) {
    const tabId = args._tabId;
    if (tabId == null) {
      return { success: true, closed: false, reason: "session has no tab" };
    }
    try {
      await chrome.tabs.remove(tabId);
      return { success: true, closed: true };
    } catch {
      return { success: true, closed: false, reason: "tab already closed" };
    }
  }
};

// src/background/tools/list_tabs.ts
var list_tabs = {
  name: "list_tabs",
  async execute(args, ctx) {
    const tabIds = tabGang(args);
    if (tabIds.length === 0) return { success: true, tabs: [] };
    const tabs = [];
    for (const id of tabIds) {
      try {
        const tab = await chrome.tabs.get(id);
        let groupTitle;
        if (tab.groupId != null && tab.groupId !== chrome.tabGroups.TAB_GROUP_ID_NONE) {
          try {
            groupTitle = (await chrome.tabGroups.get(tab.groupId)).title;
          } catch {
          }
        }
        tabs.push({
          tabId: id,
          url: tab.url ?? "",
          title: tab.title ?? "",
          active: tab.active,
          groupTitle
        });
      } catch {
      }
    }
    return { success: true, tabs };
  }
};
function tabGang(args) {
  const ids = args._tabIds;
  if (Array.isArray(ids) && ids.length > 0) return ids;
  const single = args._tabId;
  return single == null ? [] : [single];
}

// src/background/tools/close_session.ts
var close_session = {
  name: "close_session",
  async execute(args, ctx) {
    const tabIds = (() => {
      const ids = args._tabIds;
      if (Array.isArray(ids) && ids.length > 0) return ids;
      const single = args._tabId;
      return single == null ? [] : [single];
    })();
    if (tabIds.length === 0) return { success: true, closed: 0 };
    let closed = 0;
    for (const id of tabIds) {
      try {
        await chrome.tabs.remove(id);
        closed++;
      } catch {
      }
    }
    return { success: true, closed };
  }
};

// src/background/tools/index.ts
var TOOLS = [
  navigate,
  find_tab,
  evaluate,
  network,
  snapshot,
  click,
  fill,
  mouse_click,
  cdp,
  key_type,
  send_keys,
  screenshot,
  save_as_pdf,
  upload,
  close_tab,
  list_tabs,
  close_session
];
var registry = /* @__PURE__ */ new Map();
for (const tool of TOOLS) registry.set(tool.name, tool);
var TAB_LEVEL_TOOLS = /* @__PURE__ */ new Set(["close_tab", "list_tabs", "close_session"]);
function toolNames() {
  return [...registry.keys()];
}
async function dispatchTool(name, args, ctx) {
  const tool = registry.get(name);
  if (!tool) {
    throw new Error(`Unknown tool: ${name}. Available: ${toolNames().join(", ")}`);
  }
  const borrowedTab = args._tabId;
  if (borrowedTab != null && !TAB_LEVEL_TOOLS.has(name)) {
    await ctx.session.attach(borrowedTab);
    ctx.session.setLast(borrowedTab);
    delete args._tabId;
  }
  return tool.execute(args, ctx);
}

// src/background/service_worker.ts
var client = new WsClient();
var session = new BrowserSession();
var approval = new ApprovalGate();
var disposed = false;
function log(level, message, data) {
  const entry = {
    ts: (/* @__PURE__ */ new Date()).toISOString(),
    level,
    message,
    data: data ?? null
  };
  try {
    void chrome.storage.session.set({ [`openlabs_log_${entry.ts}`]: entry }).catch(() => {
    });
  } catch {
  }
  if (level === "error") console.error("[OpenLabs]", message, data ?? "");
}
async function ensureSecret() {
  const existing = await getSecret();
  if (existing) return existing;
  return rotateSecret();
}
function respond(responder, data) {
  try {
    responder(data);
  } catch {
  }
}
var captcha = new CaptchaDetector({
  session,
  sendFn: (msg) => client.send(msg)
});
var toolContext = {
  session,
  approval,
  captcha,
  send: (msg) => client.send(msg)
};
async function handleCommand(msg, responder) {
  const command = msg.command;
  const payload = msg.payload ?? {};
  log("info", `command: ${command}`);
  if (command === "approve" || command === "deny") {
    const requestId = payload.requestId;
    const resolved = approval.resolve(requestId, command === "approve");
    respond(responder, { ok: resolved });
    return;
  }
  if (command === "pair") {
    await ensureSecret();
    respond(responder, { ok: true, paired: true });
    return;
  }
  if (command === "health") {
    respond(responder, {
      ok: true,
      status: "running",
      tools: toolNames()
    });
    return;
  }
  if (command === "disconnect") {
    session.networkStop().catch(() => {
    });
    respond(responder, { ok: true });
    return;
  }
  try {
    payload.__requestId = msg.id;
    const result = await dispatchTool(command, payload, toolContext);
    if (command === "snapshot" || command === "navigate") {
      await captcha.evaluate().catch(() => {
      });
    }
    respond(responder, { ok: true, data: result });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    log("warning", `tool failed: ${command}`, message);
    respond(responder, { ok: false, error: message });
  }
}
client.setCommandHandler(async (cmd) => {
  const reply = await new Promise((resolve) => {
    const msg = {
      id: cmd.id,
      command: cmd.command,
      payload: cmd.payload ?? {}
    };
    void handleCommand(msg, resolve).catch((err) => {
      log("error", "handler crashed", err);
      resolve({ ok: false, error: String(err) });
    });
  });
  await client.send({ type: "REPLY", id: cmd.id, result: reply });
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  const msg = message;
  if (!msg || typeof msg.type !== "string") return;
  if (msg.type === "OPENLABS_PAIR") {
    void (async () => {
      await ensureSecret();
      await client.send({ type: "HELLO" });
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (msg.type === "OPENLABS_ROTATE") {
    void (async () => {
      await rotateSecret();
      await client.send({ type: "PAIR_CONFIRM" });
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (msg.type === "OPENLABS_STATUS_QUERY") {
    void (async () => {
      const has = await getSecret() !== null;
      sendResponse({ status: { connected: has } });
    })();
    return true;
  }
  if (msg.type === "OPENLABS_NETWORK_STATUS") {
    sendResponse({ status: [] });
    return true;
  }
});
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.statusCode === 403 || details.statusCode === 503) {
      void captcha.evaluate(details.statusCode).catch(() => {
      });
    }
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);
async function init() {
  if (disposed) return;
  await ensureSecret();
  log("info", "service worker started");
  await client.connect().catch(() => {
    log("warning", "initial ws connect failed (will retry)");
  });
}
chrome.runtime.onInstalled.addListener(() => {
  void init();
});
chrome.runtime.onStartup.addListener(() => {
  void init();
});
void init();
chrome.runtime.onSuspend.addListener(() => {
  disposed = true;
});
