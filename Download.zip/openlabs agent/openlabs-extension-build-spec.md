# OpenLabs Browser Extension — Build Spec

**For:** AI coding agent / builder
**Target:** Chrome Extension, Manifest V3
**Companion docs:** `universal-agent-system-prompt.md` (OpenLabs Agent core persona & rules), `browser-extension-tools.md` (tool API this extension implements)

---

## 1. Context

This extension is the execution layer for the **OpenLabs Agent** — it receives signed commands from a local backend over WebSocket and executes them in the browser. It must be secure and transparent by construction: no silent data extraction, no bypassing of user-facing protections, every consequential action auditable.

## 2. Non-negotiable security principles

These override convenience or performance if they ever conflict:

1. **No silent behavior.** Every module that reads page/network data is a read-only observer, not a bypass mechanism. If a capability could be used to extract data or act without going through the visible UI/consent flow, it is out of scope for this extension.
2. **Never bypass human-verification systems.** CAPTCHA/bot-challenge detection triggers a **pause and human handoff**, never an automated solve or workaround.
3. **All consequential actions are gated.** Purchases, login, form submission with sensitive data, downloads, and destructive operations must go through the approval flow defined by the backend — the extension does not decide these are safe on its own.
4. **Every command is authenticated.** HMAC-SHA256 signature + timestamp on every WebSocket request; replay protection via a 30-second freshness window.
5. **Secrets are never exposed to the page or to disk in plaintext.** Shared secret lives in `chrome.storage.session`, never `localStorage`, never injected into page context.
6. **Everything is logged.** Actions, signature failures, and CAPTCHA pauses are all traceable.

## 3. Project structure

```
openlabs-extension/
├── manifest.json                 # V3 Configuration & Permissions
├── background/
│   ├── service_worker.js         # Core Engine & WebSocket Connection
│   ├── ws_client.js              # HMAC Signed Requests & Replay Guard
│   └── captcha_detector.js       # Pre-emptive Captcha & Pause System
├── content/
│   ├── dom_inspector.js          # Accessibility Tree & Ref Generator
│   ├── injector.js               # Action Runner (click, type, scroll)
│   └── network_reader.js         # Transparent, read-only network observer
├── popup/
│   ├── popup.html                # Status Dashboard & Pairing UI
│   └── popup.js                  # Local Identity Check & Pairing Trigger
└── utils/
    ├── crypto.js                 # HMAC-SHA256, secret storage & rotation
    └── selectors.js              # Fast DOM Skeleton & Action Cache
```

## 4. Module specs

### `manifest.json`
- Manifest V3.
- Permissions: `activeTab`, `scripting`, `webRequest`, `storage`, `notifications`.

### `background/ws_client.js`
- Manages the WebSocket connection to the local agent server (`ws://localhost:8080`).
- Verifies every inbound command: HMAC-SHA256 signature + timestamp within a 30-second window (reject stale or unsigned requests).
- Surfaces a native alert to the user on repeated signature failures (possible attack).
- Never executes a command whose signature fails verification, no exceptions.

### `background/captcha_detector.js`
- Detects CAPTCHA/bot-challenge systems (Cloudflare, reCAPTCHA, hCaptcha) via DOM signals and HTTP status codes (403/503).
- On detection: sends `STATUS: CAPTCHA_DETECTED` to the server to pause the agent, and notifies the user to resolve it manually.
- Does not attempt automated solving or evasion under any circumstance.

### `content/dom_inspector.js`
- Builds a lightweight accessibility tree and assigns a stable `ref_id` (`ref_1`, `ref_2`, ...) to each interactive element, minimizing token/latency cost.

### `content/network_reader.js` (Transparent API Observer)
- Read-only observer of network requests/responses (status codes, headers) — functionally equivalent to the `read_network_requests` tool defined in `browser-extension-tools.md`.
- Purpose: help the agent understand page state (did the request succeed? 401/403? did data reach the DOM?) — not to extract data as a substitute for UI interaction.
- Every read is logged and attributable. No request is intercepted, modified, or used to act on the page's behalf.

### `content/injector.js`
- Executes actions (`left_click`, `type`, `form_input`, `scroll`) against a given `ref_id` or coordinate, as instructed via the signed WebSocket command.
- Before executing a click/type on an element whose visible text or `aria-label` matches sensitive-action patterns (e.g. "Pay", "Confirm Order", "Submit Payment", "Sign In", "Delete"), hold and request approval rather than executing — this check runs in code, independent of what the backend LLM already decided.

### `utils/crypto.js`
- HMAC-SHA256 signing/verification.
- Shared secret: generated at pairing time, stored in `chrome.storage.session` (never `localStorage`, never disk, never exposed to page context).
- Secret rotates on re-pairing or on suspected compromise.

### `popup/popup.js` + `popup.html`
- Pairing UI: local identity check, handshake challenge with the server, status dashboard (connected / paused / error).

## 5. Prompt to give the AI builder

> I'm building the OpenLabs Browser Extension on Manifest V3, with security and transparency as hard constraints — no silent behavior, no bypassing of human-verification systems, every consequential action logged and gated. Write the full modular codebase per this structure:
>
> 1. `manifest.json` — Manifest V3, permissions: `activeTab`, `scripting`, `webRequest`, `storage`, `notifications`.
> 2. `background/ws_client.js` — WebSocket client to `ws://localhost:8080`; verifies HMAC-SHA256 signature + timestamp (30s freshness window, reject replays); native alert on repeated signature failures.
> 3. `background/captcha_detector.js` — detects Cloudflare/reCAPTCHA/hCaptcha and 403/503 responses; sends `STATUS: CAPTCHA_DETECTED` to pause the agent and hands control to the human; never attempts to solve or bypass.
> 4. `content/dom_inspector.js` — builds a lightweight accessibility tree, assigns a unique `ref_id` to each interactive element.
> 5. `content/network_reader.js` — read-only network observer matching `read_network_requests`; logs all reads; never used to bypass the UI or extract data silently.
> 6. `content/injector.js` — executes click/type/form_input/scroll by `ref_id`; holds and requests approval before acting on elements matching sensitive-action patterns (pay, confirm, submit, sign in, delete), independent of the backend's own decision.
> 7. `utils/crypto.js` — HMAC-SHA256 signing, shared-secret management via `chrome.storage.session` only, secret rotation on re-pairing.

---

Version: 1.0 — OpenLabs
